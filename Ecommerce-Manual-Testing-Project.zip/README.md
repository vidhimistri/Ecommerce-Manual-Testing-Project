# E-Commerce Manual Testing Project

## Project Overview

Manual testing performed on an E-commerce web application.

## Modules Tested

-   Login
-   Registration
-   Cart
-   Checkout

## Testing Types

-   Functional Testing
-   Regression Testing
-   Smoke Testing

## Tools Used

-   JIRA
-   MS Excel

## Artifacts Included

-   Test Plan
-   Test Cases
-   Defect Report
-   RTM
